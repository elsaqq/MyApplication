package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class AddProductActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        val buttonAddProduct: Button = findViewById(R.id.buttonAddProduct)
        buttonAddProduct.setOnClickListener {
            addProductToFirebase()
        }
    }

    private fun addProductToFirebase() {
        val name = findViewById<EditText>(R.id.editTextProductName).text.toString().trim()
        val price =
            findViewById<EditText>(R.id.editTextProductPrice).text.toString().toDoubleOrNull()
                ?: 0.0
        val imageUrl = findViewById<EditText>(R.id.editTextProductImage).text.toString().trim()

        val product = Product(prodName = name, prodPrice = price, prodImage = imageUrl)

        // Get a reference to the Firebase database
        val database = FirebaseDatabase.getInstance()
        val productsRef = database.getReference("products")

        // Add product to Firebase
        // Using push() to generate a unique key for each product
        val newProductRef = productsRef.push()
        newProductRef.setValue(product)
            .addOnSuccessListener {
                // Handle success (e.g., show a success message or navigate back)
            }
            .addOnFailureListener {
                // Handle failure (e.g., show an error message)
            }
    }
}