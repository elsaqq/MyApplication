package com.example.myapplication




class Product(
    var productId: String = "",
    var prodName: String = "",
    var prodPrice: Double = 0.0,
    var prodImage: String = "",
    var prodAvailable: Boolean = true
)
