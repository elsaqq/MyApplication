package com.example.myapplication

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class CartAdapter(private val items: List<CartItem>) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {


    fun setCartItems(cartItems: List<CartItem>) {
        notifyDataSetChanged()
    }

    class CartViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.imageViewCartItem)
        val itemName: TextView = view.findViewById(R.id.textViewCartItemName)
        val itemPrice: TextView = view.findViewById(R.id.textViewCartItemPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = items[position]
        holder.itemName.text = cartItem.product.prodName
        holder.itemPrice.text = "$${cartItem.product.prodPrice}"

        Glide.with(holder.itemView.context)
            .load(cartItem.product.prodImage)
            .into(holder.imageView)

        // Logging for debugging
        Log.d("CartAdapter", "Item at position $position: ${cartItem.product.prodName}, Price: ${cartItem.product.prodPrice}")
    }

    override fun getItemCount(): Int {
        // Logging for debugging
        Log.d("CartAdapter", "Total items: ${items.size}")
        return items.size
    }
}