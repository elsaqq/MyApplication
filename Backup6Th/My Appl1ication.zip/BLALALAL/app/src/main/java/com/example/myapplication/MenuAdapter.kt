import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplication.Product
import com.example.myapplication.R

class MenuAdapter(
    private val menuList: List<Product>,
    private val addToCartClickListener: (Product) -> Unit
) : RecyclerView.Adapter<MenuAdapter.MenuViewHolder>() {

    class MenuViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.imageViewMenuItem)
        val nameView: TextView = view.findViewById(R.id.textViewMenuItemName)
        val priceView: TextView = view.findViewById(R.id.textViewMenuItemPrice)
        val addToCartButton: Button = view.findViewById(R.id.buttonAddToCart)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_menu, parent, false)
        return MenuViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        val menuItem = menuList[position]
        holder.nameView.text = menuItem.prodName
        holder.priceView.text = String.format("$%.2f", menuItem.prodPrice)

        Glide.with(holder.itemView.context)
            .load(menuItem.prodImage)
            .into(holder.imageView)

        // Handle "Add to Cart" button click
        holder.addToCartButton.setOnClickListener {
            addToCartClickListener(menuItem)
        }
    }

    override fun getItemCount() = menuList.size
}
