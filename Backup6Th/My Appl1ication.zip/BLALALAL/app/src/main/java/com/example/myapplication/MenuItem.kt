package com.example.myapplication



    data class MenuItem(
        val itemId: String,
        val itemName: String,
        val itemPrice: Double,
        val itemImage: String
    )

