package com.example.myapplication

import android.util.Log

data class CartItem(val product: Product, var quantity: Int)

object ShoppingCart {
    private val items = mutableListOf<CartItem>()

    fun addProduct(product: Product) {
        val existingItem = items.find { it.product.productId == product.productId }
        if (existingItem != null) {
            existingItem.quantity++
        } else {
            items.add(CartItem(product, 1))
        }
        Log.d("ShoppingCart", "Product added: ${product.prodName}, Total items: ${items.size}")


    }

    fun removeProduct(product: Product) {
        val existingItem = items.find { it.product.productId == product.productId }
        if (existingItem != null) {
            if (existingItem.quantity > 1) {
                existingItem.quantity--
            } else {
                items.remove(existingItem)
            }
        }
    }

    fun getTotalPrice(): Double {


        return items.sumOf { it.product.prodPrice * it.quantity }

    }

    fun getCartItems(): List<CartItem> {
        return items.toList()
    }

    fun clearCart() {
        items.clear()
    }
}
