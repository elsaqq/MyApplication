package com.example.myapplication

import MenuAdapter
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MenuListActivity : AppCompatActivity() {

    private lateinit var menuAdapter: MenuAdapter
    private lateinit var database: DatabaseReference
    private val cartItems = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_list)

        database = FirebaseDatabase.getInstance().getReference("products")

        val menuRecyclerView: RecyclerView = findViewById(R.id.menuRecyclerView)
        val cartButton: Button = findViewById(R.id.cartButton)

        // Initialize RecyclerView and MenuAdapter
        val menuItems = ArrayList<Product>()
        menuAdapter = MenuAdapter(menuItems) { product ->
            // Handle adding the product to the cart
            addToCart(product)
        }

        menuRecyclerView.adapter = menuAdapter
        menuRecyclerView.layoutManager = LinearLayoutManager(this)

        // Fetch products from the database
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                menuItems.clear()
                for (snapshot in dataSnapshot.children) {
                    val product = snapshot.getValue(Product::class.java)
                    product?.let { menuItems.add(it) }
                }
                menuAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle database error
            }
        })

        // Handle cart button click
        cartButton.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }
    }

    private fun addToCart(product: Product) {
        ShoppingCart.addProduct(product)
        Toast.makeText(this, "${product.prodName} added to cart", Toast.LENGTH_SHORT).show()

        // Notify CartActivity to update the cart
        val updateCartIntent = Intent(this, CartActivity::class.java)
        updateCartIntent.action = "UPDATE_CART"
        sendBroadcast(updateCartIntent)
    }
}
