package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var totalPriceTextView: TextView
    private lateinit var adapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        recyclerView = findViewById(R.id.cartRecyclerView)
        totalPriceTextView = findViewById(R.id.totalPriceTextView)

        // Initialize adapter with cart items from ShoppingCart
        adapter = CartAdapter(ShoppingCart.getCartItems())
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        updateTotalPrice()
    }

    override fun onResume() {
        super.onResume()

        // Handle the broadcast action to update the cart
        val intent = intent
        if (intent.action == "UPDATE_CART") {
            updateRecyclerView()
        }

        updateTotalPrice()
    }

    private fun updateTotalPrice() {
        val totalPrice = ShoppingCart.getTotalPrice()
        totalPriceTextView.text = "Total Price: $$totalPrice"
    }

    private fun updateRecyclerView() {
        val cartItems = ShoppingCart.getCartItems()
        Log.d("CartActivity", "Number of items in cart: ${cartItems.size}")

        // Update adapter data
        adapter.notifyDataSetChanged()
    }
}
