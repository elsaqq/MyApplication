package com.example.myapplication

import java.util.UUID


class Product(
    var productId: String = "",
    var prodName: String = "",
    var prodPrice: Double = 0.0,
    var prodImage: String = "",
    var prodAvailable: Boolean = true
)


data class Order(
    val orderId: String = UUID.randomUUID().toString(),
    val cusId: String,
    val orderDate: String,
    val orderTime: String,
    var orderStatus: String
)
