package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShoppingCartActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var cartProductAdapter: ProductAdapter
    private lateinit var totalPriceTextView: TextView
    private lateinit var placeOrderButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shopping_cart)

        totalPriceTextView = findViewById(R.id.totalPriceTextView)
        placeOrderButton = findViewById(R.id.placeOrderButton)
        recyclerView = findViewById(R.id.cartRecyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        cartProductAdapter = ProductAdapter(CartManager.getCartItems().toMutableList(), isAdmin = false, CartManager, isShoppingCartView = true)
        recyclerView.adapter = cartProductAdapter

        updateTotalPrice()
        cartProductAdapter.onProductRemovedFromCart = { updateTotalPrice() }

        placeOrderButton.setOnClickListener {
            placeOrder()
        }
    }

    override fun onResume() {
        super.onResume()
        updateCartItems()
    }

    private fun updateTotalPrice() {
        totalPriceTextView.text = "Total: $${CartManager.getTotalPrice()}"
    }

    private fun updateCartItems() {
        cartProductAdapter.updateProductList(CartManager.getCartItems().toMutableList())
        updateTotalPrice()
    }

    private fun placeOrder() {
        val customerId = getCurrentCustomerId()
        val orderTotal = CartManager.getTotalPrice()

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        val currentTime = timeFormat.format(Date())

        val newOrder = Order(
            cusId = customerId,
            orderDate = currentDate,
            orderTime = currentTime,
            orderStatus = "Pending"
        )

        val databaseReference = FirebaseDatabase.getInstance().getReference("orders")
        databaseReference.child(newOrder.orderId).setValue(newOrder)

        navigateToOrderConfirmation(orderTotal)
        CartManager.clearCart()
    }

    private fun navigateToOrderConfirmation(orderTotal: Double) {
        val intent = Intent(this, OrderConfirmationActivity::class.java).apply {
            putExtra("ORDER_TOTAL", orderTotal)
        }
        startActivity(intent)
    }

    private fun getCurrentCustomerId(): String {
        val currentUser = FirebaseAuth.getInstance().currentUser
        return currentUser?.uid ?: "unknown_user"
    }

}
