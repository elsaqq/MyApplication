package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OrderConfirmationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_confirmation)

        val confirmationTextView: TextView = findViewById(R.id.confirmationTextView)
        val orderTotal = intent.getDoubleExtra("ORDER_TOTAL", 0.0)

        // Set confirmation message with total amount
        confirmationTextView.text = "Thank you for your order! Your total is: $${String.format("%.2f", orderTotal)}"
    }
}
