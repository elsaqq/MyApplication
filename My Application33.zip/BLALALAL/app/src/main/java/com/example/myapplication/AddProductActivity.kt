package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AddProductActivity : AppCompatActivity() {

    private lateinit var spinnerProducts: Spinner
    private lateinit var editTextProductName: EditText
    private lateinit var editTextProductPrice: EditText
    private lateinit var editTextProductImage: EditText
    private lateinit var database: DatabaseReference
    private var selectedProductId: String? = null
    private var productsMap = mutableMapOf<String, Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        spinnerProducts = findViewById(R.id.spinnerProducts)
        editTextProductName = findViewById(R.id.editTextProductName)
        editTextProductPrice = findViewById(R.id.editTextProductPrice)
        editTextProductImage = findViewById(R.id.editTextProductImage)
        database = FirebaseDatabase.getInstance().getReference("products")

        setupSpinner()

        findViewById<Button>(R.id.buttonAddProduct).setOnClickListener {
            addProduct()
        }

        findViewById<Button>(R.id.buttonEditProduct).setOnClickListener {
            if (selectedProductId != null) {
                editProduct()
            } else {
                Toast.makeText(this, "Select a product to edit", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.buttonRemoveProduct).setOnClickListener {
            removeProduct()
        }
    }


    private fun setupSpinner() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val productList = ArrayList<String>()
                dataSnapshot.children.forEach { snapshot ->
                    val product = snapshot.getValue(Product::class.java)
                    val productId = snapshot.key
                    if (product != null && productId != null) {
                        productsMap[productId] = product
                        productList.add(productId)
                    }
                }
                val adapter = ArrayAdapter(this@AddProductActivity, android.R.layout.simple_spinner_dropdown_item, productList)
                spinnerProducts.adapter = adapter
                spinnerProducts.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                        val productId = parent.getItemAtPosition(position) as String
                        selectedProductId = productId
                        val product = productsMap[productId]
                        editTextProductName.setText(product?.prodName)
                        editTextProductPrice.setText(product?.prodPrice.toString())
                        editTextProductImage.setText(product?.prodImage)
                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        selectedProductId = null
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@AddProductActivity, "Failed to load products.", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun addProduct() {
        val name = editTextProductName.text.toString().trim()
        val price = editTextProductPrice.text.toString().toDoubleOrNull() ?: 0.0
        val imageUrl = editTextProductImage.text.toString().trim()

        if (name.isEmpty() || imageUrl.isEmpty()) {
            Toast.makeText(this, "Name and Image URL must not be empty", Toast.LENGTH_SHORT).show()
            return
        }

        val newProduct = Product(prodName = name, prodPrice = price, prodImage = imageUrl)
        val newProductRef = database.push()
        newProduct.productId = newProductRef.key ?: ""

        newProductRef.setValue(newProduct).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Toast.makeText(this, "Product added successfully", Toast.LENGTH_SHORT).show()
                clearFields()
                setupSpinner() // Refresh the spinner with updated data
            } else {
                Toast.makeText(this, "Failed to add product", Toast.LENGTH_SHORT).show()
            }
        }
    }







    private fun editProduct() {
        val name = editTextProductName.text.toString().trim()
        val price = editTextProductPrice.text.toString().toDoubleOrNull() ?: 0.0
        val imageUrl = editTextProductImage.text.toString().trim()

        if (name.isEmpty() || imageUrl.isEmpty()) {
            Toast.makeText(this, "Name and Image URL must not be empty", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedProduct = Product(prodName = name, prodPrice = price, prodImage = imageUrl)
        selectedProductId?.let { productId ->
            database.child(productId).setValue(updatedProduct).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Product updated successfully", Toast.LENGTH_SHORT).show()
                    clearFields()
                    setupSpinner() // Refresh the spinner with updated data
                } else {
                    Toast.makeText(this, "Failed to update product", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun removeProduct() {
        selectedProductId?.let { productId ->
            database.child(productId).removeValue().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Product removed successfully", Toast.LENGTH_SHORT).show()
                    clearFields()
                    setupSpinner() // Refresh the spinner with updated data
                } else {
                    Toast.makeText(this, "Failed to remove product", Toast.LENGTH_SHORT).show()
                }
            }
        } ?: Toast.makeText(this, "No product selected to remove", Toast.LENGTH_SHORT).show()
    }

    private fun clearFields() {
        editTextProductName.setText("")
        editTextProductPrice.setText("")
        editTextProductImage.setText("")
        selectedProductId = null
        spinnerProducts.setSelection(0)
    }
}

