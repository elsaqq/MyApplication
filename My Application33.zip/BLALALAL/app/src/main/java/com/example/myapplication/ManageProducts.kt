package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class ManageProducts : AppCompatActivity() {

    private val databaseReference = FirebaseDatabase.getInstance().getReference("products")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)


        val addProductButton: Button = findViewById(R.id.buttonAddProduct)

        addProductButton.setOnClickListener {
            addProductToDatabase("Coffee", 2.5, "url_to_image", true)
        }
    }

    private fun addProductToDatabase(productName: String, productPrice: Double, productImage: String, productAvailable: Boolean) {
        // Generate a unique key for the product
        val productId = databaseReference.push().key ?: return

        // Create a Product object
        val product = Product(productId, productName, productPrice, productImage, productAvailable)

        // Push the product to the database under the generated key
        databaseReference.child(productId).setValue(product)
            .addOnSuccessListener {
                Log.d("AddProduct", "Product added successfully to the database")
            }
            .addOnFailureListener { e ->
                Log.e("AddProduct", "Failed to add product: ${e.message}")
            }
    }

    data class Product(
        val productId: String = "",
        val productName: String = "",
        val productPrice: Double = 0.0,
        val productImage: String = "",
        val productAvailable: Boolean = false
    )
}
