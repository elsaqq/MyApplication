package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class OrderManagementActivity : AppCompatActivity() {

    private lateinit var orderId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_management)

        orderId = intent.getStringExtra("ORDER_ID") ?: ""

        // Example display function (implement this according to your needs)
        displayOrderDetails(orderId)

        findViewById<Button>(R.id.buttonPreparing).setOnClickListener {
            updateOrderStatus("Preparing")
        }

        findViewById<Button>(R.id.buttonCollect).setOnClickListener {
            updateOrderStatus("Collect")
        }
    }

    private fun displayOrderDetails(orderId: String) {
        // Fetch order details from Firebase and display
    }

    private fun updateOrderStatus(status: String) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("orders")
        databaseReference.child(orderId).child("orderStatus").setValue(status)
        // Handle success or failure
    }
}
