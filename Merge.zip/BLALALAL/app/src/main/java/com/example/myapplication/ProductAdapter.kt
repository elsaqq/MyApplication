package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(
    private var productList: MutableList<Product>, // Use a mutable list for product management
    private val isAdmin: Boolean,
    private val cartManager: CartManager? = null,
    private val isShoppingCartView: Boolean = false
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    var onProductAddedToCart: ((Double) -> Unit)? = null
    var onProductRemovedFromCart: ((Double) -> Unit)? = null

    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.imageViewProduct)
        val nameView: TextView = view.findViewById(R.id.textViewProductName)
        val priceView: TextView = view.findViewById(R.id.textViewProductPrice)
        val addToCartButton: Button = view.findViewById(R.id.buttonAddToCart)
        val removeButton: Button = view.findViewById(R.id.removeButton)
    }

    fun updateProductList(newList: MutableList<Product>) {
        productList = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.nameView.text = product.prodName
        holder.priceView.text = String.format("$%.2f", product.prodPrice)
        Glide.with(holder.itemView.context).load(product.prodImage).into(holder.imageView)

        if (!isAdmin) {
            holder.addToCartButton.visibility = if (isShoppingCartView) View.GONE else View.VISIBLE
            holder.addToCartButton.setOnClickListener {
                cartManager?.addToCart(product)
                onProductAddedToCart?.invoke(cartManager?.getTotalPrice() ?: 0.0)
            }

            holder.removeButton.visibility = if (isShoppingCartView) View.VISIBLE else View.GONE
            holder.removeButton.setOnClickListener {
                cartManager?.removeFromCart(product)
                productList.removeAt(position)
                notifyItemRemoved(position)
                notifyItemRangeChanged(position, productList.size)
                onProductRemovedFromCart?.invoke(cartManager?.getTotalPrice() ?: 0.0)
            }
        } else {
            holder.addToCartButton.visibility = View.GONE
            holder.removeButton.visibility = View.GONE
        }
    }

    override fun getItemCount() = productList.size
}
