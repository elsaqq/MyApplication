package com.example.myapplication

object CartManager {
    private val cartItems = mutableListOf<Product>()

    fun removeFromCart(product: Product) {
        cartItems.remove(product)
    }


    fun clearCart() {
        cartItems.clear()
    }

    fun addToCart(product: Product) {
        cartItems.add(product)
    }

    fun getCartItems(): List<Product> = cartItems

    fun getTotalPrice(): Double = cartItems.sumOf { it.prodPrice }



}
