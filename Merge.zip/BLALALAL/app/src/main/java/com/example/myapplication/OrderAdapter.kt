package com.example.myapplication

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.FirebaseDatabase

class OrderAdapter(
    private var orderList: List<Order>,
    private val onOrderStatusChanged: (Order) -> Unit  // Callback for when an order status is changed
) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val orderIdView: TextView = view.findViewById(R.id.textViewOrderId)
        val orderDateView: TextView = view.findViewById(R.id.textViewOrderDate)
        val orderTimeView: TextView = view.findViewById(R.id.textViewOrderTime)
        val orderStatusView: TextView = view.findViewById(R.id.textViewOrderStatus)
        val customerIDView: TextView = view.findViewById(R.id.textViewCustomerID)
        val collectButton: Button = view.findViewById(R.id.buttonCollect)  // Collect button
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orderList[position]
        holder.orderIdView.text = "ID: ${order.orderId}"
        holder.orderDateView.text = "Date: ${order.orderDate}"
        holder.orderTimeView.text = "Time: ${order.orderTime}"
        holder.orderStatusView.text = "Status: ${order.orderStatus}"
        holder.customerIDView.text = "Customer ID: ${order.cusId}"

        holder.collectButton.setOnClickListener {
            Log.d("OrderAdapter", "Collect button clicked for order ID: ${order.orderId}")
            if (order.orderStatus == "Preparing") {
                val orderRef = FirebaseDatabase.getInstance().getReference("orders").child(order.orderId)
                orderRef.child("orderStatus").setValue("Collected")
                    .addOnSuccessListener {
                        Log.d("OrderAdapter", "Order status updated successfully")
                        // Refresh data or UI here
                    }
                    .addOnFailureListener { exception ->
                        Log.e("OrderAdapter", "Error updating order status", exception)
                    }
            }
        }

    }


    override fun getItemCount() = orderList.size
}
